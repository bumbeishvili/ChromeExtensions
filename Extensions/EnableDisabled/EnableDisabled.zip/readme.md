##Download extension from [chrome web store](https://chrome.google.com/webstore/detail/enable-all-disabled-butto/aonhflmdemlehgbnfmhpdmoeeolokelm?authuser=1)

### Test added extension on [codepen](https://codepen.io/bumbeishvili/debug/BzzYom)

#### Screenshots

![](https://raw.githubusercontent.com/bumbeishvili/Assets/master/Projects/Extensions/EnableDisabledComponents/Scr/Enable.png)
